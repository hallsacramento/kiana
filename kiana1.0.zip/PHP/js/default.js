var clicked = false;
var host = "http://localhost/files/";

function likeFrame(url){

        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", host + 'sql/like.php?url=' + url);
        ifrm.style.width = "0px";
        ifrm.style.height = "0px";
        ifrm.setAttribute("hidden", true);

        document.body.appendChild(ifrm);

        window.alert("Liked!");
}

function deslikeFrame(url){

        var ifrm = document.createElement("iframe");
        ifrm.setAttribute("src", host + 'sql/deslike.php?url=' + url);
        ifrm.style.width = "0px";
        ifrm.style.height = "0px";
        ifrm.setAttribute("hidden", true);

        document.body.appendChild(ifrm);        

        window.alert("Desliked!");
}    


